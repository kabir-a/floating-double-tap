package com.example.floatingdoubletap

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.ImageView

class FloatingService: Service() {

    private lateinit var wm: WindowManager
    private lateinit var view: View

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        params.gravity = Gravity.TOP or Gravity.START
        params.x = 200
        params.y = 200

        view = LayoutInflater.from(this).inflate(R.layout.floating_button, null)
        val btn = view.findViewById<ImageView>(R.id.floatingButton)

        btn.setOnClickListener {
            val loc = IntArray(2)
            btn.getLocationOnScreen(loc)
            val x = loc[0] + btn.width/2
            val y = loc[1] + btn.height/2

            val i = Intent("DOUBLE_TAP_ACTION")
            i.putExtra("x", x)
            i.putExtra("y", y)
            sendBroadcast(i)
        }

        wm.addView(view, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        wm.removeView(view)
    }

    override fun onBind(p0: Intent?): IBinder? = null
}
