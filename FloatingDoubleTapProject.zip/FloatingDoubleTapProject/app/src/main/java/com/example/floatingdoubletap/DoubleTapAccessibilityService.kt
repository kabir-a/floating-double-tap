package com.example.floatingdoubletap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path

class DoubleTapAccessibilityService: AccessibilityService() {

    private val receiver = object: BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "DOUBLE_TAP_ACTION") {
                val x = intent.getIntExtra("x", 0).toFloat()
                val y = intent.getIntExtra("y", 0).toFloat()
                performDoubleTap(x, y)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        registerReceiver(receiver, IntentFilter("DOUBLE_TAP_ACTION"))
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(receiver)
    }

    private fun performDoubleTap(x: Float, y: Float) {
        fun tap(delay: Long): GestureDescription {
            val p = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(p, delay, 60)
            return GestureDescription.Builder().addStroke(stroke).build()
        }

        dispatchGesture(tap(0), null, null)
        dispatchGesture(tap(150), null, null)
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
